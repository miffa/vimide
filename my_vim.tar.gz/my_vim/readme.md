# install vim8

# install vim rc
+ cd ~
+ mv vimrc to .vimrc
+ mv vim_rumtime  to .vim_runtime 

# install something
+ :GoInstallBinaries
+ :GoUpdateBinaries

# go 1.15


